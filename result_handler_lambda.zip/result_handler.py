import json
import boto3
import os

DYNAMODB_TABLE_NAME = os.environ.get('DYNAMODB_TABLE_NAME')
textract_client = boto3.client('textract')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DYNAMODB_TABLE_NAME)

def lambda_handler(event, context):
    print("Sonuç işleyici Lambda tetiklendi.")
    
    try:
        message = json.loads(event['Records'][0]['Sns']['Message'])
        job_id = message['JobId']
        status = message['Status']
        
        s3_object = message['DocumentLocation']['S3Object']
        bucket = s3_object['Bucket']
        key = s3_object['Name'] 

        job_tag = message.get('JobTag')
        if not job_tag:
            print("HATA: JobTag bulunamadı. DynamoDB anahtarları eksik.")
            return

        unit_id, source_id = job_tag.split('|')

        if status != 'SUCCEEDED':
            print(f"Textract işi başarılı olmadı. Durum: {status}")
            table.update_item(
                Key={'unit_id': unit_id, 'source_id': source_id},
                UpdateExpression="SET #st = :status_val",
                ExpressionAttributeNames={'#st': 'status'},
                ExpressionAttributeValues={':status_val': 'TEXTRACT_FAILED'}
            )
            return

        print(f"Textract işi başarılı. Job ID: {job_id}. Metin alınıyor...")

        full_text = ""
        next_token = None
        
        while True:
            params = {'JobId': job_id}
            if next_token:
                params['NextToken'] = next_token
            
            response = textract_client.get_document_text_detection(**params)
            
            blocks = response['Blocks']
            for block in blocks:
                if block['BlockType'] == 'LINE':
                    full_text += block['Text'] + '\n'
            
            next_token = response.get('NextToken')
            if not next_token:
                break

        print("Metin başarıyla alındı. Veritabanı güncelleniyor.")

        table.update_item(
            Key={'unit_id': unit_id, 'source_id': source_id},
            UpdateExpression="SET extracted_text = :text, #st = :status_val",
            ExpressionAttributeNames={'#st': 'status'},
            ExpressionAttributeValues={
                ':text': full_text,
                ':status_val': 'COMPLETED'
            }
        )
        
        print("Veritabanı başarıyla güncellendi.")
        return {'statusCode': 200, 'body': 'İşlem tamamlandı.'}

    except Exception as e:
        print(f"Bir hata oluştu: {str(e)}")
        return {'statusCode': 500, 'body': 'Hata oluştu.'}